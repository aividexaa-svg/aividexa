import crypto from "crypto";
import { headers } from "next/headers";
import { adminDb } from "@/firebase/admin";

export async function POST(req: Request) {
  // 🔴 Razorpay requires RAW body
  const body = await req.text();

  const signature =
    (await headers()).get("x-razorpay-signature") || "";

  const expectedSignature = crypto
    .createHmac(
      "sha256",
      process.env.RAZORPAY_WEBHOOK_SECRET!
    )
    .update(body)
    .digest("hex");

  // 🔒 Verify webhook signature
  if (expectedSignature !== signature) {
    console.error("❌ Invalid Razorpay webhook signature");
    return new Response("Invalid signature", { status: 400 });
  }

  const event = JSON.parse(body);

  // ✅ Payment successful
  if (event.event === "payment.captured") {
    const payment = event.payload.payment.entity;

    const userId = payment.notes?.userId;
    const plan = payment.notes?.plan;

    if (!userId || !plan) {
      console.warn("⚠️ Missing userId or plan in Razorpay notes");
      return Response.json({ received: true });
    }

    await adminDb.collection("users").doc(userId).update({
      plan,
      planStartedAt: new Date(),
      paymentProvider: "razorpay",
      paymentStatus: "paid",
      lastPaymentId: payment.id,
    });

    console.log("✅ User upgraded:", userId, plan);
  }

  return Response.json({ received: true });
}
