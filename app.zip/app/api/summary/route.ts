import { NextResponse } from "next/server";
import Groq from "groq-sdk";
import { buildSummaryPrompt } from "@/app/Summarizer/summaryPrompt";
import { YoutubeTranscript } from "youtube-transcript";

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY!,
});

/* ================= HELPERS ================= */

// 🔥 Robust YouTube ID extractor
function extractVideoId(url: string): string | null {
  try {
    const u = new URL(url);

    // youtu.be/<id>
    if (u.hostname.includes("youtu.be")) {
      return u.pathname.slice(1);
    }

    // youtube.com/watch?v=<id>
    if (u.searchParams.get("v")) {
      return u.searchParams.get("v");
    }

    // youtube.com/embed/<id>
    if (u.pathname.startsWith("/embed/")) {
      return u.pathname.split("/embed/")[1];
    }

    // youtube.com/shorts/<id>
    if (u.pathname.startsWith("/shorts/")) {
      return u.pathname.split("/shorts/")[1];
    }

    return null;
  } catch {
    return null;
  }
}

function formatTime(seconds: number) {
  const m = Math.floor(seconds / 60)
    .toString()
    .padStart(2, "0");
  const s = Math.floor(seconds % 60)
    .toString()
    .padStart(2, "0");
  return `${m}:${s}`;
}

/* ================= MULTI-LANG CAPTION FETCH ================= */

async function fetchYoutubeTranscript(url: string) {
  const videoId = extractVideoId(url);
  if (!videoId) throw new Error("Invalid YouTube URL");

  const LANG_FALLBACKS = [
    "en",
    "en-US",
    "en-GB",
    "hi",
    "es",
    "fr",
    "de",
    "auto",
  ];

  let lastError: any = null;

  for (const lang of LANG_FALLBACKS) {
    try {
      const transcript = await YoutubeTranscript.fetchTranscript(videoId, {
        lang,
      });

      if (transcript && transcript.length > 0) {
        return {
          text: transcript.map(t => t.text).join(" "),
          timestamped: transcript.map(t => ({
            time: formatTime(t.offset / 1000),
            text: t.text,
          })),
          language: lang,
        };
      }
    } catch (err) {
      lastError = err;
    }
  }

  throw new Error("Transcript not available for this video");
}

/* ================= API ================= */

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const {
      content,
      youtubeUrl,
      summaryType,
      style,
    } = body;

    if ((!content && !youtubeUrl) || !summaryType || !style) {
      return NextResponse.json(
        { error: "Invalid summary payload" },
        { status: 400 }
      );
    }

    let inputText = content?.trim();
    let timestampedChunks: { time: string; text: string }[] = [];
    let detectedLang: string | undefined;

    // 🔥 YouTube captions (multi-language safe)
    if (!inputText && youtubeUrl) {
      const data = await fetchYoutubeTranscript(youtubeUrl);
      inputText = data.text;
      timestampedChunks = data.timestamped;
      detectedLang = data.language;
    }

    if (!inputText) {
      return NextResponse.json(
        { error: "No content or transcript available" },
        { status: 400 }
      );
    }

    // 🔒 PROMPT BUILT ONLY ON BACKEND
    const prompt = buildSummaryPrompt({
      content: inputText,
      youtubeUrl,
      summaryType,
      style,
      timestamped:
        summaryType === "timestamped" ? timestampedChunks : undefined,
      language: detectedLang,
    });

    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.4,
      max_tokens: 1100,
    });

    const text = completion.choices?.[0]?.message?.content?.trim();

    if (!text) {
      return NextResponse.json(
        { error: "AI returned empty response" },
        { status: 502 }
      );
    }

    return NextResponse.json({ text });

  } catch (err: any) {
    const msg =
      err.message === "Transcript not available for this video"
        ? "This video has no captions. Please use another video or paste text."
        : err.message === "Invalid YouTube URL"
        ? "Invalid YouTube URL. Please paste a full video link."
        : "Summary generation failed";

    console.error("Summary API error:", err.message || err);

    return NextResponse.json(
      { error: msg },
      { status: 500 }
    );
  }
}
